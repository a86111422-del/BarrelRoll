package ru.minecraft.barrelroll;

import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod("barrelroll")
@Mod.EventBusSubscriber(modid = "barrelroll", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class BarrelRoll {
    private static float currentRoll = 0;
    private static float lastYaw = 0;

    @SubscribeEvent
    public static void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.isGamePaused()) return;

        PlayerEntity player = mc.player;
        float yaw = player.rotationYaw;
        float yawDelta = yaw - lastYaw;

        // Плавная коррекция поворота (чтобы не дергалось на 360 градусах)
        if (yawDelta > 180) yawDelta -= 360;
        if (yawDelta < -180) yawDelta += 360;

        float targetRoll = 0;

        // Включаем наклон только если игрок летит на элитрах
        if (player.isElytraFlying()) {
            targetRoll = yawDelta * 4.0f; // 4.0 - это чувствительность
        }

        // Ограничиваем угол, чтобы не закружилась голова
        if (targetRoll > 45) targetRoll = 45;
        if (targetRoll < -45) targetRoll = -45;

        // Математика плавного наклона
        currentRoll = currentRoll + (targetRoll - currentRoll) * 0.1f;

        // ТА САМАЯ КОМАНДА: поворот картинки по оси Z
        GlStateManager.rotatef(currentRoll, 0, 0, 1);

        lastYaw = yaw;
    }
}
